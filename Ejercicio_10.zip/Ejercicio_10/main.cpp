#include <iostream>
#include <string>
#include <vector>

using namespace std;
template <typename ... Args>
int min_size(Args ... args)
{
    int tam;
    int minimo = 10000;

    for (auto &v : {args ...})
    {
        tam = v.size();
        if (tam < minimo)
        {
            minimo = v.size();
        }
    }
    return minimo;

}




int main() {
    vector<int> v1 = {11};
    vector<int> v2 = {21, 22, 23, 1, 2};
    vector<int> v3 = {31, 32, 33, 4};

    cout << "El minimo es: " << min_size(v2, v3) << endl;
    cout << "El minimo es: " << min_size(v1, v2, v3) << endl;

    return 0;
}