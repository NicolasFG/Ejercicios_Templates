#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <iterator>

using namespace std;


template <typename ... Args>
vector <vector<int>> zip (Args ... args)
{
    vector <vector<int>> resultado;
    vector <int> parcial;
    vector<int>();

    int longitud;
    int i;
    int j;
    int k;

    for (auto &v: {args ...}) {
        //Se obtiene un iterador al inicio de la lista
        list<int> temp = v;
        list<int>::iterator it = temp.begin();
        longitud = v.size();

        while (it != temp.end()) {
            parcial.push_back(*it++);
        }
    }
        for (i = 0; i < longitud; i++)
        {
            vector<int> temporal;
            k = 0;
            j = i;
            while (k <longitud)
            {
                temporal.push_back(parcial[j]);
                j = j+longitud;
                k++;
            }
            resultado.push_back(temporal);
            temporal.empty();
        }
        return resultado;

}


int main()
{
    list<int> v1 = {11, 12, 13};
    list<int> v2 = {21, 22, 23};
    list<int> v3 = {31, 32, 33};

    vector<vector<int>> resultado = zip (v1,v2,v3);

    for (int i = 0; i<resultado.size(); i++)
    {
        for (int j = 0; j<resultado[i].size(); j++)
        {
            cout << resultado[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}