#include <iostream>
#include <vector>
using namespace std;

template <typename T>
struct max_head
{
    T info;

    //Encuentra el mayor valor en la pila
    int find_max()
    {
        int max = 0; //-10000;
        for (int i = 0; i < info.size(); i++)
        {
            if (info[i] > max)
            {
                max = info[i];
            }
        }
        return max;
    }

    //Inserta un item al final
    void insert(int data)
    {
        info.push_back(data);
    }

    //Remueve un item del final de la pila y lo retorna
    int borrar()
    {
        int temporal = info [info.size() -1 ];
        info.pop_back();

        return temporal;

    }


    template <typename Contenedor>
    ostream& operator<< (ostream& out,  max_heap<Contenedor> heap)
    {

    }






    template <typename Contenedor>
    istream& operator << (istream& in,  max_head <Contenedor>& heap){
        in<<info.push_back(data);
        return in;
    }








    void print ()
    {
        for (int i = 0; i < info.size(); i++)
        {
            cout << info[i] << " ";
        }
    }
};

int main()
{
    max_head <vector<int>> pila;
    //Inserto en la pila
    pila.insert(2);
    pila.insert(3);
    pila.insert(4);
    pila.insert(5);
    pila.insert(7);
    pila.insert(3);

    cout << "El maximo es: " << pila.find_max() << endl;

    cout << "Se borro el item: " << pila.borrar() << endl;

    pila.print();
    return 0;
}