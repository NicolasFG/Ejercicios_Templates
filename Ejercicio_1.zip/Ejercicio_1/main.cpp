#include <iostream>

using namespace std;
template <typename T>

int absolute(T a)
{
    if (a < 0)
    {
        auto resultado = a*-1;
        cout << resultado;
    }
    else {
        auto resultado = a;
        cout << resultado;
    }
}



int main()
{
    absolute(3);
    cout << endl;
    absolute(-2000000000);
    cout << endl;
    absolute(3.4);
    cout << endl;
    absolute(200020202);

    return 0;
}