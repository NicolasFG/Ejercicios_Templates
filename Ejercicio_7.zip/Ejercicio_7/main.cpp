#include <iostream>
#include <string>

using namespace std;
template <typename T1, typename T2, typename T3>
void unpack (T1 &a, T2 &b, T3 &c)

{
    a = c.first;
    b = c.second;
}

int main() {
    int key;
    string name;
    pair <int, string> p1 = {1321, "Jose Perez"};

    unpack(key,name,p1) ;


    cout << "El primer parametro es: " << key << ", " << "el segundo parametor es: "<< name << endl;
    return 0;
}