#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <iterator>


using namespace std;

template <typename ...Args>
int sum_productos(Args ... args)
{

    //Resultado de la suma de los productos
    int resultado;
    //Tengo dos vectores
    //Datos es el vector principal en donde guardare los datos leidos
    vector<int> datos;
    //Creo un temporal en donde guardare
    vector<int> temp;

    //Hago un for que recorro el vector y lo guardo en mi vector datos
    for (auto &v:{args ...})
    {
        datos.push_back(v);
    }

    //Igualo resultado a 0
    resultado = 0;
    //Mi temporal lo igual a datos
    temp = datos;

    //Hago un fort que recorre mi el tamaño de mi vector
    for (int i = 0; i < datos.size(); i++)
    {
        //igualo los numeros pares a par
        int par = datos[i] % 2;
        //si es par entro al if
        if (par == 0)
        {
            //Hago otro for que recorre el temporal
            for (int j = 0; j < temp.size(); j++)
            {
                //pongo el valor impar del temporal a impar
                int impar = temp[j] % 2;
                //si es impar entro a la condicion
                if (impar != 0)
                {
                    //multiplico los datos y luego lo sumo a resultado
                    resultado = resultado + (datos [i] * temp[j]);
                }
            }
        }
    }
    //retorno el resultado
    return resultado;
}

int main() {
    cout << "La suma del producto de los pares con los impares es: " << sum_productos(1,2,3,4,5);
    return 0;
}