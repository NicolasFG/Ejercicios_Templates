#include <iostream>
#include <vector>

using namespace std;

template <typename Contenedor, typename n>
auto delete_items (Contenedor &c, n numero) {
    //Recibo como parametros un contenedor y el numero que quiero eliminar.

   //auto it1 = c.begin();
   vector<int> temp;

    //Recorrer el contenedor y lo guardo en un temporal v3
    for (int i = 0; i < c.size(); i++) {
        while (c[i] == numero)
        {
            c.erase(c.begin() + i);
        }
        temp.push_back(c[i]);

    }

    for (int j : temp)
    {
        cout << j;
    }
}


int main() {

    vector <int> v1 = {2,2,2,2,4,5,6};
    delete_items(v1,2);



    return 0;
}