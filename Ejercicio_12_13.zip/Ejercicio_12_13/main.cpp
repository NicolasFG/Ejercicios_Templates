#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <iterator>
#include <algorithm>


using namespace std;


template <typename t1, typename t2>

bool busqueda_binaria(t1 arr, t2 buscado)
{
    int arriba = arr.size()-1;
    int abajo = 0;
    int centro;
    while (abajo <= arriba)
    {
        centro = (arriba + abajo) /2;
        if (arr [centro] == buscado)
            return true;
        else
            if (buscado < arr[centro])
                arriba = centro -1;
            else abajo = centro +1;

    }
    return false;
}

int main() {
    int retorno;
    int valor;

    vector<int> v1 = {31, 32, 33, 21, 22, 23, 11, 12, 13};

    //Se ordena el vector, condicion requerida para la busqueda binaria

    sort(v1.begin(), v1.end());
    valor = 21;

    if (busqueda_binaria(v1,valor))
    {
        cout << "El valor indicado fue encontrado" <<" "<< valor;
    }
    else{
        cout << "El valor indicado No fue encontrado" <<" "<< valor;
    }





    return 0;
}