#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <iterator>


using namespace std;


template <typename ... Args>
vector<int> generar_contenedor(Args ... args) {
    vector<int> datos;

    //Ingresamos el conjunto de datos en el contenedor
    for (auto &v: {args ...}) {
        datos.push_back(v);
    }
    return datos;
}


int main() {
    vector<int> v1 = generar_contenedor(1,2,3,4,5);
    for (int i : v1)
    {
        cout << i << " ";
    }
    cout <<endl;
    vector<int> v2 = generar_contenedor(6, 7, 8, 9, 10);

    for (int i : v2)
    {
        cout << i <<" ";
    }

    return 0;
}