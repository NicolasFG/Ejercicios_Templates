#include <iostream>
#include <string>
#include <tuple>


using namespace std;


template <typename t1, typename t2, typename t3, typename t4, typename t5>
void unpack(t1 &a, t2 &b, t3 &c, t4 &d, t5 e){
    a = get<0>(e);
    b = get<1>(e);
    c = get<2>(e);
    d = get<3>(e);

}

int main() {

    int key;
    string primer_nombre;
    string segundo_nombre;
    double altura;

    tuple<int,string,string,double> p1 = {1321, "Jose", "Perez", 1.68};
    unpack(key, primer_nombre, segundo_nombre, altura, p1);
    cout << key <<" "<< primer_nombre <<" "<<segundo_nombre <<" "<< altura<<endl;

    return 0;
}