#include <iostream>
#include <string>
#include <vector>

using namespace std;

template <typename T1 , typename T2>
vector<vector<int>> split_range(T1 a, T2 b) {
    vector<vector<int>> resultado;
    int contador = 0;
    int cociente = a.size() / b;
    int residuo = a.size() % b;


    for (int i = 0; i < cociente; i++) {
        vector<int> parcial;

        for (int j = i * cociente; j < (cociente + i * cociente); j++) {
            parcial.push_back(a[j]);
            contador = j;
        }

        resultado.push_back(parcial);
        parcial.empty();

    }

    if (residuo != 0) {
        vector<int> parcial;

        for (int k = contador + 1; k < a.size(); k++) {
            parcial.push_back(a[k]);
        }
        resultado.push_back(parcial);

    }
    return resultado;

}

int main()
{

   int n = 3;
   vector<int> v1 = {1,2,3,4,5,6,7};

   //Dividimos el vector
   vector<vector<int>> resultado= split_range(v1,n);

   for (int i = 0; i< resultado.size(); i++)
   {
       cout << "resultado["<<i<<"] = {";

       for (int j = 0; j < resultado[i].size(); j++)
       {
           cout<<" "<<resultado[i][j]<<" ";
       }
       cout << "};";
       cout << endl;
   }

    return 0;
}